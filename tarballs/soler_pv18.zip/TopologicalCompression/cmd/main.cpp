/// \date February 2017.
///
/// \brief Command line program example for scalar field smoothing.

// include the local headers
#include                  <ttkTopologicalCompression.h>
#include                  <ttkTopologicalCompressionReader.h>
#include                  <ttkProgramBase.h>
#include                  <vtkXMLImageDataWriter.h>
#include                  <vtkSmartPointer.h>
#include                  <string.h>

// Arg c
// -i /home/madblade/thesis/ttk/git-repo/ttk/data/foot-10.10-both.vti -c -tol 1 -ratio 1 -o test.ttk
// -i foot-raw.vti -c -tol 15 -zfpBitBudget 0 -o test.ttk
// -i foot-raw.vti -c -tol 15 -zfpBitBudget 8 -o test.ttk
// -i foot-raw.vti -c -tol 15 -SQ r -o test.ttk

// -i noisyGaussian.vti -c -tol 5 -o gauss_tol5_fullseg.ttk
// -i noisyGaussian.vti -c -tol 5 -zfpBitBudget 4 -o gauss_tol5_zfp4.ttk
// -i noisyGaussian.vti -c -tol 5 -zfpBitBudget 8 -o gauss_tol5_zfp8.ttk
// -i noisyGaussian.vti -c -tol 5 -zfpBitBudget 16 -o gauss_tol5_zfp16.ttk
// -i noisyGaussian.vti -c -tol 5 -SQ r -o gauss_tol5_sqr.ttk
// -i noisyGaussian.vti -c -tol 5 -SQ d -o gauss_tol5_sqd.ttk
// -i noisyGaussian.vti -c -tol 5 -topo -o gauss_tol5_topo.ttk

// Arg d
// -i gauss_tol5_topo.ttk -d -o gauss_tol5_topo.vti
// -i gauss_tol5_zfp8.ttk -d -o gauss_tol5_zfp8.vti
// -i gauss_tol5_zfp4.ttk -d -o gauss_tol5_zfp4.vti
// -i test.ttk -d -o dectest.vti

int main(int argc, char **argv) {

  vtkProgram<ttkTopologicalCompression> compression;

  // specify local parameters to the TTK module with default values.
  int scalarFieldId = 0;
  bool compress = false;
  bool decompress = false;
  bool dontSubDivide = false;
  bool useTopologicalSimplification = false;
  bool zfpOnly = false;
  double tolerance = 1;
  double zfpBitBudget = 0;
  string sqMethod = "";

  // register these arguments to the command line parser
  compression.parser_.setArgument("f", &scalarFieldId, "Scalar field identifier", true);
  compression.parser_.setOption("c", &compress, "Compress");
  compression.parser_.setOption("d", &decompress, "Decompress");
  compression.parser_.setOption("simplify", &useTopologicalSimplification, "Use topological simplification.");
  compression.parser_.setArgument("SQ", &sqMethod, "Use SQ compressor: r (range_based), d (domain-based)", true);
  compression.parser_.setArgument("tol", &tolerance, "Error tolerance", true);
  compression.parser_.setArgument("zfpBitBudget", &zfpBitBudget, "Per vertex ZFP bit budget", true);
  compression.parser_.setOption("topo", &dontSubDivide, "Topological preservation only.");
    // 0 -> 0 bit for zfp
  compression.parser_.setOption("zfpOnly", &zfpOnly, "Use only zfp.");

  int ret = compression.init(argc, argv);
  if (ret != 0 && !decompress) return ret;
  string outputFilePath = compression.getOutputFilePath();
  if (outputFilePath.size() < 1) return -1; // Not enforced in program base
  if (zfpBitBudget > 0 && zfpBitBudget < 64.0 && strcmp(sqMethod.c_str(), "") != 0) {
    cout << "Cannot combine SQ quantization with lossy ZFP encoding." << endl;
    return -2;
  }
  if (!compress && !decompress) {
    cout << "Specify -c for compression, -d for decompression." << endl;
    return -3;
  }
  if (compress == decompress) {
    cout << "Cannot compress and decompress at the same time." << endl;
    return -3;
  }
  if (zfpOnly) {
    if (zfpBitBudget <= 0 || zfpBitBudget > 64) {
      cout << "Invalid zfp argument." << endl;
      return -4;
    }
  }

  if (compress) {
    cout << "[MainThread] Compression" << endl;

    compression.ttkObject_->SetSQMethod(sqMethod);
    compression.ttkObject_->SetSubdivide(dontSubDivide);
    compression.ttkObject_->SetUseTopologicalSimplification(useTopologicalSimplification);
    compression.ttkObject_->SetTolerance(tolerance);
    compression.ttkObject_->SetZFPBitBudget(zfpBitBudget);
    compression.ttkObject_->SetZFPOnly(zfpOnly);
    compression.ttkObject_->SetOutputFile(outputFilePath);
    ret = compression.run();

    // TODO [LOW] use zlib here.

    if (ret != 0) return ret;
    // ret = compression.save();
  }

  else if (decompress) {
    cout << "[MainThread] Decompression" << endl;

    string inputFilePath = compression.parser_.firstInputFilePath;

    vtkSmartPointer<ttkTopologicalCompressionReader> reader =
      vtkSmartPointer<ttkTopologicalCompressionReader>::New();
    reader->SetFileName(inputFilePath.c_str());
    // reader->Update(0);
    // reader->GetOutput();

    vtkSmartPointer<vtkXMLImageDataWriter> writer =
      vtkSmartPointer<vtkXMLImageDataWriter>::New();
    writer->SetFileName(outputFilePath.c_str());
    writer->SetInputConnection(reader->GetOutputPort());
    writer->Write();
    ret = 0;
  }

  return ret;
}

