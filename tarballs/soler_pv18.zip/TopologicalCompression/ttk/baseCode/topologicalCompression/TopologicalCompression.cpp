#include                  "TopologicalCompression.h"

TopologicalCompression::TopologicalCompression() {

  inputData_ = NULL;
  outputData_ = NULL;

  triangulation_ = NULL;

  segmentation_ = NULL;
  sqMethod_ = "";
  nbSegments = 0;
  nbVertices = 0;
}

TopologicalCompression::~TopologicalCompression() {
  
}

