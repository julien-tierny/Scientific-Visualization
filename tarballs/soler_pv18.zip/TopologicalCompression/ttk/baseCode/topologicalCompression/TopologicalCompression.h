/// \ingroup baseCode
/// \class ttk::TopologicalCompression 
/// \date 20/04/2017
///
/// \brief TTK %topologicalCompression processing package.
///
/// %TopologicalCompression is a TTK processing package that takes a scalar field on the input 
/// and produces a scalar field on the output.
///
/// \sa ttk::Triangulation
/// \sa vtkTopologicalCompression.cpp %for a usage example.

#ifndef _TOPOLOGICALCOMPRESSION_H
#define _TOPOLOGICALCOMPRESSION_H

// base code includes

#include                  <Triangulation.h>
#include                  <Wrapper.h>
#include                  <PersistenceDiagram.h>
#include                  <FTMTreePP.h>
#include                  <TopologicalSimplification.h>
#include                  <DataTypes.h>
#include                  <Debug.h>

// std

#include                  <cstdlib>
#include                  <cmath>
#include                  <iostream>
#include                  <string.h>
#include                  <algorithm>
#include                  <stack>

namespace ttk
{
    
  class TopologicalCompression : public Debug
  {
      
    using idVertex = int;

    public:

      TopologicalCompression();
      
      ~TopologicalCompression();
      
      template<typename type>
      static type abs(const type var){
         return (var >= 0) ? var : -var;
      }

      template<typename type>
      static type abs_diff(const type var1, const type var2){
         return (var1 > var2) ? var1 - var2 : var2 - var1;
      }

      /// Execute the package.
      /// \pre If this TTK package uses ttk::Triangulation for fast mesh 
      /// traversals, the function setupTriangulation() must be called on this 
      /// object prior to this function, in a clearly distinct pre-processing 
      /// steps. An error will be returned otherwise.
      /// \note In such a case, it is recommended to exclude 
      /// setupTriangulation() from any time performance measurement.
      /// \param argment Dummy integer argument.
      /// \return Returns 0 upon success, negative values otherwise.
      template <class dataType>
        int execute(const double &tolerance);


      template <class dataType>
        int computePersistencePairs(
          vector<tuple<idVertex, idVertex, dataType> > &JTPairs,
          vector<tuple<idVertex, idVertex, dataType> > &STPairs,
          dataType* inputScalars_,
          int* inputOffsets);

      /// Pass a pointer to an input array representing a scalarfield.
      /// The expected format for the array is the following:
      /// <vertex0-component0> <vertex0-component1> ... <vertex0-componentN>
      /// <vertex1-component0> <vertex1-component1> ... <vertex1-componentN>
      /// <vertexM-component0> <vertexM-component1> ... <vertexM-componentN>.
      /// The array is expected to be correctly allocated.
      /// \param data Pointer to the data array.
      /// \return Returns 0 upon success, negative values otherwise.
      /// \sa setVertexNumber() and setDimensionNumber().
      inline int setInputDataPointer(void *data){
        inputData_ = data;
        return 0;
      }

      /// Pass a pointer to an output array representing a scalar field.
      /// The expected format for the array is the following:
      /// <vertex0-component0> <vertex0-component1> ... <vertex0-componentN>
      /// <vertex1-component0> <vertex1-component1> ... <vertex1-componentN>
      /// <vertexM-component0> <vertexM-component1> ... <vertexM-componentN>.
      /// The array is expected to be correctly allocated.
      /// \param data Pointer to the data array.
      /// \return Returns 0 upon success, negative values otherwise.
      /// \sa setVertexNumber() and setDimensionNumber().
      inline int setOutputDataPointer(void *data) {
        outputData_ = data;
        return 0;
      }

      inline int setSQ(string sqMethod) {
        sqMethod_ = sqMethod;
        return 0;
      }

      inline int setZFPOnly(bool z) {
        zfpOnly_ = z;
        return 0;
      }

      inline int setSubdivide(bool dontSubdivide) {
        dontSubdivide_ = dontSubdivide;
        return 0;
      }
      
      inline int setUseTopologicalSimplification(bool useTopologicalSimplification) {
        useTopologicalSimplification_ = useTopologicalSimplification;
        return 0;
      }

      // Triangulation.
      inline int setupTriangulation(Triangulation *triangulation)
      {
        triangulation_ = triangulation;
        if (triangulation_) triangulation_->preprocessVertexNeighbors();
        return 0;
      }

      inline int getNbVertices() {
        return this->nbVertices;
      }

      inline int getNbSegments() {
        return this->nbSegments;
      }

      inline int* getSegmentation() {
        return this->segmentation_;
      }

      inline void* getMapping() {
        return this->mapping_;
      }

      inline void* getCriticalConstraints() {
        return this->criticalConstraints_;
      }

    protected:
    
      void                        *inputData_, *outputData_;
      string                      sqMethod_;
      bool                        zfpOnly_;
      bool                        dontSubdivide_;
      bool                        useTopologicalSimplification_;

      Triangulation               *triangulation_;
      TopologicalSimplification   topologicalSimplification;

      int                         *segmentation_;
      void                        *mapping_;
      int                         criticalConstraintsSize_;
      void                        *criticalConstraints_;

      int nbVertices;
      int nbSegments;
  };
}


template <class dataType>
int TopologicalCompression::computePersistencePairs(
  vector<tuple<idVertex, idVertex, dataType> > &JTPairs,
  vector<tuple<idVertex, idVertex, dataType> > &STPairs,
  dataType* inputScalars_,
  int* inputOffsets)
{

  // Compute offsets
  const idVertex numberOfVertices = triangulation_->getNumberOfVertices();
  vector<idVertex> voffsets(numberOfVertices);
  std::copy(inputOffsets, inputOffsets+numberOfVertices, voffsets.begin());

  // Get contour tree
  ftm::FTMTreePP ftmTreePP; // Paires de persistence
  
  ftmTreePP.setupTriangulation(triangulation_, false);
  ftmTreePP.setVertexScalars(inputScalars_);
  ftmTreePP.setTreeType(ftm::TreeType::Join_Split); // TODO check
  ftmTreePP.setVertexSoSoffsets(voffsets);
  // ftmTreePP.setLessPartition(true);
  // for now, only one thread is supported
  ftmTreePP.setThreadNumber(threadNumber_);
  //ftmTreePP.setThreadNumber(1);
  ftmTreePP.build<dataType>();
  
  // To del segmt sth like
  ftmTreePP.setSegmentation(false);

  
//   #ifdef withOpenMP
//   #pragma omp parallel sections
//   #endif
  {
//     #ifdef withOpenMP
//     #pragma omp section
//     #endif
    ftmTreePP.computePersistencePairs<dataType>(JTPairs, true);
    
//     #ifdef withOpenMP
//     #pragma omp section
//     #endif
    ftmTreePP.computePersistencePairs<dataType>(STPairs, false);
  }

  return 0;
}

template <class dataType>
int TopologicalCompression::execute(
  const double &tol)
{

  Timer t;
  Timer t1;
  
  {
    stringstream msg;
    msg << "[TopologicalCompression] Starting compression... "
        << endl;
    dMsg(std::cout, msg.str(), timeMsg);
  }
  
  // check the consistency of the variables -- to adapt
  #ifndef withKamikaze
  if (!triangulation_) return -1;
  if (!inputData_) return -2;
  if (!outputData_) return -3;
  // if (tol < 0 || tol > 100) return -4;
  #endif

  dataType *outputData = (dataType *) outputData_;
  dataType *inputData = (dataType *) inputData_;
  int vertexNumber = triangulation_->getNumberOfVertices();

  int* inputOffsets = new int[vertexNumber];
  for (int i = 0; i < vertexNumber; ++i)
    inputOffsets[i] = i;

  // 1. Compute persistence pairs.
  vector<tuple<dataType, idVertex>> topoIndices;

  // Compute global min & max
  dataType iter;
  dataType maxValue = inputData[0];
  int maxIndex = 0;
  for (int i = 1; i < vertexNumber; ++i) {
    iter = inputData[i];
    if (iter > maxValue) {
      maxIndex = i;
      maxValue = iter;
    }
  }

  dataType minValue = inputData[0];
  int minIndex = 0;
  for (int i = 1; i < vertexNumber; ++i) {
    iter = inputData[i];
    if (iter < minValue) {
      minIndex = i;
      minValue = iter;
    }
  }

  topoIndices.push_back(make_tuple(maxValue, maxIndex));
  topoIndices.push_back(make_tuple(minValue, minIndex));
  double tolerance = 0.01 * tol * (maxValue - minValue);
  
  {
    stringstream msg;
    msg << "[TopologicalCompression] Computed min/max in "
        << t.getElapsedTime() << " s. (" << threadNumber_
        << " thread(s))."
        << endl;
    dMsg(std::cout, msg.str(), timeMsg);
    t.reStart();
  }

  bool sqDomain = false;
  bool sqRange = false;

  const char* sq = sqMethod_.c_str();
  int nbCrit = 0;
  int *simplifiedConstraints = NULL;
  if (strcmp(sq, "") == 0 && !zfpOnly_) {
    // No SQ: perform topological control

    vector<tuple<idVertex, idVertex, dataType>> JTPairs;
    vector<tuple<idVertex, idVertex, dataType>> STPairs;
    computePersistencePairs<dataType>(JTPairs, STPairs, inputData, inputOffsets);
    
    {
      stringstream msg;
      msg << "[TopologicalCompression] Persistence pairs computed in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }
  
    int nbJ = JTPairs.size();
    int nbS = STPairs.size();
    int *critConstraints = new int[2*nbJ+2*nbS];

    topologicalSimplification.setupTriangulation(triangulation_);

    dataType maxEpsilon = 0;
    dataType epsilonSum2 = 0;
    dataType epsilonSum1 = 0;
    dataType persistentSum2 = 0;
    dataType persistentSum1 = 0;

    // Join
    for (int i = 0; i < nbJ; ++i) {
      int cp1 = get<0>(JTPairs[i]);
      int cp2 = get<1>(JTPairs[i]);
      dataType idt1 = inputData[cp1];
      dataType idt2 = inputData[cp2];
      dataType p1 = std::max(idt2, idt1) - std::min(idt2, idt1);
      if (p1 > tolerance) {
        persistentSum2 += (p1 * p1);
        persistentSum1 += abs<dataType>(p1);
        int type1 = topologicalSimplification.getCriticalType(cp1, inputData, inputOffsets);
        int type2 = topologicalSimplification.getCriticalType(cp2, inputData, inputOffsets);
        if (type1 == 0) {
          topoIndices.push_back(make_tuple(idt1, cp1));
        }
        if (type2 == 0) {
          topoIndices.push_back(make_tuple(idt2, cp2));
        }

        nbCrit += 2;
        critConstraints[2*i]   = cp1;
        critConstraints[2*i+1] = cp2;
      }
      else {
        if (maxEpsilon < abs<dataType>(p1)) maxEpsilon = abs<dataType>(p1);
        epsilonSum2 += (p1 * p1);
        epsilonSum1 += abs<dataType>(p1);
        critConstraints[2*i] = -1;
        critConstraints[2*i+1] = -1;
      }
    }
    
    {
      stringstream msg;
      msg << "[TopologicalCompression] Join pairs post-processed in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }

    // Split
    for (int i = nbJ; i < nbJ + nbS; ++i) {
      int si = i - nbJ;
      int cp1 = get<0>(STPairs[si]);
      int cp2 = get<1>(STPairs[si]);
      dataType idt1 = inputData[cp1];
      dataType idt2 = inputData[cp2];
      dataType p1 = std::max(idt2, idt1) - std::min(idt2, idt1);
      if (p1 > tolerance) {
        persistentSum2 += (p1 * p1);
        persistentSum1 += abs<dataType>(p1);
        // Saddle selection.
        int type1 = topologicalSimplification.getCriticalType(cp1, inputData, inputOffsets);
        int type2 = topologicalSimplification.getCriticalType(cp2, inputData, inputOffsets);
        if (type1 == 0) {
          topoIndices.push_back(make_tuple(idt1, cp1));
        }
        if (type2 == 0) {
          topoIndices.push_back(make_tuple(idt2, cp2));
        }

        nbCrit += 2;
        critConstraints[2*i]   = cp1;
        critConstraints[2*i+1] = cp2;
      }
      else {
        if (maxEpsilon < p1) maxEpsilon = abs<dataType>(p1);
        epsilonSum2 += (p1 * p1);
        epsilonSum1 += abs<dataType>(p1);
        critConstraints[2*i] = -1;
        critConstraints[2*i+1] = -1;
      }
    }
    
    {
      stringstream msg;
      msg << "[TopologicalCompression] Split pairs post-processed in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }

    simplifiedConstraints = new int[nbCrit];
    {
      int j = 0;
      for (int i = 0; i < 2*nbJ+2*nbS; ++i) {
        int c = critConstraints[i];
        if (c != -1) simplifiedConstraints[j++] = c;
      }
    }

    //cout << "\t[TopologicalCompression] Expecting W_1 " << persistentSum1 << " preserved." << endl;
    //cout << "\t[TopologicalCompression] Expecting W_1 " << epsilonSum1 << " deleted." << endl;

    //cout << "\t[TopologicalCompression] Expecting W_2 " << persistentSum2 << " preserved." << endl;
    //cout << "\t[TopologicalCompression] Expecting W_2 " << epsilonSum2 << " deleted." << endl;

    //cout << "\t[TopologicalCompression] Expecting B_inf " << maxEpsilon << " greatest deleted." << endl;

    {
      stringstream msg;
      msg << "[TopologicalCompression] Got pairs in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }

    // 2. Perform topological simplification with constraints.
    if (useTopologicalSimplification_) {
        topologicalSimplification.setInputScalarFieldPointer(inputData);
        topologicalSimplification.setOutputScalarFieldPointer(outputData);
        topologicalSimplification.setInputOffsetScalarFieldPointer(inputOffsets);
        int* outputOffsets = new int[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i) outputOffsets[i] = i;
        topologicalSimplification.setOutputOffsetScalarFieldPointer(outputOffsets);
        topologicalSimplification.setVertexIdentifierScalarFieldPointer(simplifiedConstraints);
        topologicalSimplification.setConstraintNumber(nbCrit);
        int status = 0;
        status = topologicalSimplification.execute<dataType>();
        if (status != 0) { return status; }
    }

    {
      stringstream msg;
      msg << "[TopologicalCompression] Performed simplification in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }
    delete[] critConstraints;

  } else if (strcmp(sq, "r") == 0 || strcmp(sq, "R") == 0) {
    // Range-based SQ: simple range quantization (automatic)
    sqRange = true;
  } else if (strcmp(sq, "d") == 0 || strcmp(sq, "D") == 0) {
    // Domain-based SQ: range quantization + later domain control
    sqDomain = true;
  } else if (zfpOnly_) {
    return 0;
  } else {
    {
      stringstream msg;
      msg << "[TopologicalCompression] Unrecognized SQ option ("
          << sqMethod_ << ")."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
    }
    return -3;
  }

  // 3. Subdivision and attribution of a topological index

  auto cmp = [](const tuple<dataType, idVertex>& a,
                const tuple<dataType, idVertex>& b)
  { return get<0>(a) < get<0>(b); };
  std::sort(topoIndices.begin(), topoIndices.end(), cmp);
  vector<tuple<dataType, idVertex>> segments;
    // ith rank = ith segment (from bottom)
    // 0: value
    // 1: critical point index or -1 if !critical
  bool subdivide = !dontSubdivide_;
  int l = (int) topoIndices.size();
  if (l < 1) {  
    {
      stringstream msg;
      msg << "[TopologicalCompression] Trivial subdivision performed."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
    }
    segments.push_back(topoIndices[l-1]);
  }
  else {
    for (int i = 0; i < l; ++i) {
      dataType v0 = get<0>(topoIndices[i]);
      if (i == l-1) {
        segments.push_back(topoIndices[i]);
        break;
      }

      dataType v1 = get<0>(topoIndices[i+1]);
      idVertex i1 = get<1>(topoIndices[i+1]);
      double diff = (double) (v1 - v0);

      if (diff == 0) continue;
      if (!subdivide || (diff < (dataType) tolerance)) {
        segments.push_back(make_tuple(v1, i1));
      } else {
        // Subdivide.
        double nbSegments = std::ceil(diff / tolerance);
        for (int j = 0, nbs = (int) nbSegments; j < nbs; ++j) {
          dataType sample = v0 + j * tolerance;
          idVertex idVertex1 = i1;
          segments.push_back(make_tuple(sample, idVertex1));
        }
      }
    }
  }

  {
    stringstream msg;
    msg << "[TopologicalCompression] Subdivision/topological index"
        << " attribution in "
        << t.getElapsedTime() << " s. (" << threadNumber_
        << " thread(s))."
        << endl;
    dMsg(std::cout, msg.str(), timeMsg);
    t.reStart();
  }

  // 4. Affect segment value to all points.
  int *segmentation = new int[vertexNumber];
  std::sort(segments.begin(), segments.end(), cmp);
  for (int i = 0; i < vertexNumber; ++i) {
    dataType scalar = inputData[i];

    auto begin = segments.begin();
    auto end = segments.end();
    auto it = std::lower_bound(segments.begin(), segments.end(),
                               make_tuple(scalar, -1), cmp);

    if (it != end) {
      tuple<dataType, idVertex> tt = *it;
      int j = it - begin;
      int last = (int) segments.size() - 1;
      if (j < last) {
        dataType dtv = get<0>(tt);
        if (j > 0) {
          dtv = 0.5 * (dtv + get<0>(*(it-1)));
        }

        outputData[i] = dtv;
        int seg = j;
        segmentation[i] = seg;
      } else {
        segmentation[i] = last;
        outputData[i] = get<0>(tt); // maxValue;
      }
    }

  }
  
  {
    stringstream msg;
    msg << "[TopologicalCompression] Affected values in "
        << t.getElapsedTime() << " s. (" << threadNumber_
        << " thread(s))."
        << endl;
    dMsg(std::cout, msg.str(), timeMsg);
    t.reStart();
  }

  // 4.1. Simplify mapping
  int segmentsSize = (int) segments.size();
  vector<bool> affectedSegments;
  affectedSegments.reserve(segmentsSize);
  vector<int> oob;
  for (int i = 0; i < vertexNumber; ++i) {
    int seg = segmentation[i];
    if (seg >= segmentsSize && std::find(oob.begin(), oob.end(), seg) == oob.end()) oob.push_back(seg);
    else if (seg >= 0) affectedSegments[seg] = true;
    else cout << "Negative segment encoutered (" << i << ")" << endl;
  }
  vector<int> empty;
  for (int i = 0; i < segmentsSize; ++i) {
    if (!affectedSegments[i]) empty.push_back(i);
  }

  std::sort(oob.begin(), oob.end());
  std::sort(empty.begin(), empty.end());
  int indexLast = -1;
  if (oob.size() > empty.size()) {
    cout << "[TopologicalCompression] WARN oob size > empty size: "
         << oob.size() << ", " << empty.size() << endl;
  } else {
    // Replace
    for (int i = 0; i < vertexNumber; ++i) {
      int seg = segmentation[i];
      if (seg >= segmentsSize) {
        auto begin = oob.begin();
        auto end = oob.end();
        auto it = std::lower_bound(begin, end, seg);
        if (it != end) {
          int j = it - begin;
          segmentation[i] = empty[j];
          affectedSegments[j] = true;
        }
      } else if (!affectedSegments[seg]) {
        cout << "[TopologicalCompression] Something impossible happened" << endl;
      }
    }

    if (empty.size() > oob.size()) {
      vector<int> map2(segmentsSize, -1);
      for (int i = 0; i < segmentsSize; ++i) {
        if (affectedSegments[i]) continue;
        // bool associated = false;
        for (int j = (int) (segmentsSize - 1); j > i; --j) {
          if (!affectedSegments[j] || map2[j] > 0) continue;
          map2[j] = i;
          affectedSegments[j] = false;
          affectedSegments[i] = true;
          // associated = true;
          break;
        }
      }

      bool doneAffecting = false;
      for (int i = 0; i < segmentsSize; ++i) {
        if (!affectedSegments[i]) {
          doneAffecting = true;
        } else {
          if (doneAffecting) {
            cout << "[TopologicalCompression] Hole detected at "
                 << i << "th segment." << endl;
          } else {
            indexLast = i;
          }
        }
      }

      for (int i = 0; i < vertexNumber; ++i) {
        int seg = segmentation[i];
        if (map2[seg] > 0) segmentation[i] = map2[seg];
      }
    }
  }
  
  {
    stringstream msg;
    msg << "[TopologicalCompression] Simplified mapping in "
        << t.getElapsedTime() << " s. (" << threadNumber_
        << " thread(s))."
        << endl;
    dMsg(std::cout, msg.str(), timeMsg);
    t.reStart();
  }

  // 5. Expose mapping.
  vector<tuple<double, int>>* mapping = new vector<tuple<double, int>>();
  bool *already = new bool[vertexNumber];
  for (int i = 0; i < vertexNumber; ++i) already[i] = false; // init

  for (int i = 0; i < vertexNumber; ++i) {
    int vert = segmentation[i];
    if (!already[vert]) {
      already[vert] = true;
      dataType dttt = outputData[i];
      mapping->push_back(make_tuple((double) dttt, vert));
    }
  }
  delete[] already;
  
  {
    stringstream msg;
    msg << "[TopologicalCompression] Exposed mapping in "
        << t.getElapsedTime() << " s. (" << threadNumber_
        << " thread(s))."
        << endl;
    dMsg(std::cout, msg.str(), timeMsg);
    t.reStart();
  }

  // 6. SQ-D correction step.
  // Indices stay compact.
  if (sqDomain && !sqRange) {
    vector<bool> markedVertices(vertexNumber); // false by default
    vector<bool> markedSegments(segmentsSize); // false by default
    int newIndex = (int) segmentsSize;

    for (int i = 0; i < vertexNumber; ++i) {
      // Skip processed vertices.
      if (markedVertices[i]) continue;

      int seg = segmentation[i];
      bool newSegment = markedSegments[seg];
      dataType minNewSegment = inputData[i];
      dataType maxNewSegment = minNewSegment;

      if (!newSegment) {
        markedSegments[seg] = true;
      }

      // Neighborhood search with seed = i
      stack<int> s;
      s.push(i);

      while (!s.empty()) {
        // Get next element.
        int vertex = s.top();
        s.pop();

        // Mark vertex as processed.
        markedVertices[vertex] = true;

        // New region was detected.
        if (newSegment) {
          // Affect new segmentation id to all vertices in region.
          segmentation[vertex] = newIndex;
          // Progressively compute min & max on local region.
          dataType currentValue = inputData[vertex];
          if (currentValue > maxNewSegment) maxNewSegment = currentValue;
          if (currentValue < minNewSegment) minNewSegment = currentValue;
        }

        // Get neighbors.
        int neighborNumber = triangulation_->getVertexNeighborNumber(vertex);
        for(int j = 0; j < neighborNumber; ++j) {
          int neighbor;
          triangulation_->getVertexNeighbor(vertex, j, neighbor);

          // Add current neighbor to processing stack.
          if (!markedVertices[neighbor] && segmentation[neighbor] == seg) {
            s.push(neighbor);
          }
        }
      }

      // Affect a value to the new segmentation index.
      if (newSegment) {
        dataType result = (maxNewSegment + minNewSegment) / 2;
        segments.push_back(make_tuple(result, newIndex));
        mapping->push_back(make_tuple((double) result, newIndex));
        newIndex++; // Set index for next potential segment.
      }
    }
    
    {
      stringstream msg;
      msg << "[TopologicalCompression] SQ-D correction step in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }
  }

  this->mapping_ = mapping;

  // 7. [ZFP]: max constraints, min constraints
  vector<tuple<idVertex, double, int>>* criticalConstraints = new
    vector<tuple<idVertex, double, int>>();

  if (!sqDomain && !sqRange && !zfpOnly_) {
    for (int i = 0; i < nbCrit; ++i) {
      int id = simplifiedConstraints[i];
      dataType val = inputData[id];
      int type = topologicalSimplification.getCriticalType(id, inputData, inputOffsets);
      if (type == -1 // Local_minimum
          || type == 1 // Local_maximum
          || type == 0)
      {
        criticalConstraints->push_back(make_tuple(id, (double) val, type));
      } else { // 0 -> Saddle
      }
    }
    
    {
      stringstream msg;
      msg << "[TopologicalCompression] Exposed constraints in "
          << t.getElapsedTime() << " s. (" << threadNumber_
          << " thread(s))."
          << endl;
      dMsg(std::cout, msg.str(), timeMsg);
      t.reStart();
    }
  }
  this->criticalConstraints_ = criticalConstraints;
  delete[] simplifiedConstraints;
  
  {
    stringstream msg;
    if (indexLast > -1) {
      if (indexLast+1 != (int)mapping->size()) {
        cout << "[TopologicalCompression] possible affectation mismatch "
             << "(" << (indexLast+1) << ", " << mapping->size() << ")" << endl;
      }
    }

    int nbSegments = indexLast > -1 ? indexLast+1 : (int) segments.size() - 1;
    this->nbSegments = nbSegments;
    this->nbVertices = vertexNumber;
    msg << "[TopologicalCompression] Affected " << nbSegments
        << " segment" << (nbSegments > 1 ? "s" : "") << "." << endl;
    msg << "[TopologicalCompression] Data-set (" << vertexNumber
      << " points) processed in "
      << t1.getElapsedTime() << " s. (" << threadNumber_
      << " thread(s))."
      << endl;
    dMsg(std::cout, msg.str(), timeMsg);
  }

  // Expose segmentation.
  segmentation_ = segmentation;

  return 0;
}

#endif // TOPOLOGICALCOMPRESSION_H
