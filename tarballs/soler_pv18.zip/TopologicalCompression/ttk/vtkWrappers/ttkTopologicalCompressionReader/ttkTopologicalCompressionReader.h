/// \ingroup vtkWrappers
/// \class ttkTopologicalCompressionReader
/// \date 21/04/2017
///
/// \brief VTK-filter that wraps the topologicalCompressionWriter processing package.

#ifndef _VTK_TOPOLOGICALCOMPRESSIONREADER_H
#define _VTK_TOPOLOGICALCOMPRESSIONREADER_H

// TTK
#include                  <TopologicalSimplification.h>
#include                  <ttkTopologicalCompressionWriter.h>
#include                  <ttkWrapper.h>
// #include                  <DataTypes.h>

// VTK
#include                  <vtkImageAlgorithm.h>
#include                  <vtkDataObject.h>
#include                  <vtkPolyData.h>
#include                  <vtkPoints.h>
#include                  <vtkStreamingDemandDrivenPipeline.h>
#include                  <vtkDemandDrivenPipeline.h>
#include                  <vtkCharArray.h>
#include                  <vtkDataArray.h>
#include                  <vtkDataSet.h>
#include                  <vtkDataSetAlgorithm.h>
#include                  <vtkDoubleArray.h>
#include                  <vtkFiltersCoreModule.h>
#include                  <vtkFloatArray.h>
#include                  <vtkInformation.h>
#include                  <vtkIntArray.h>
#include                  <vtkObjectFactory.h>
#include                  <vtkPointData.h>
#include                  <vtkSmartPointer.h>
#include                  <vtkUnstructuredGrid.h>
#include                  <vtkCellData.h>
#include                  <vtkAlgorithm.h>

// STD
#include                  <string>
#include                  <iostream>
#include                  <fstream>
#include                  <limits.h>

// Other
// #include                  "zfp/zfp.cpp"

class VTKFILTERSCORE_EXPORT ttkTopologicalCompressionReader
    : public vtkImageAlgorithm
{

  public:
    static ttkTopologicalCompressionReader *New();
    vtkTypeMacro(ttkTopologicalCompressionReader, vtkAlgorithm);

    int ReadMetaData();

    int ReadTopology();

    int ReadGeometry(
      vtkImageData *data,
      void *outPtr,
      double ZFPRate
    );

    vtkSetStringMacro(FileName);
    vtkGetStringMacro(FileName);

    vtkSetMacro(DataScalarType, int);
    vtkGetMacro(DataScalarType, int);

  protected:

    ttkTopologicalCompressionReader();
    ~ttkTopologicalCompressionReader() {
      delete[] this->FileName;
    }

    vector<tuple<int, double, int>> CriticalConstraints;
    vector<int>* Mapping;
    vector<int>* Segmentation;
    char *FileName;

    // Image data reader internals.

    int DataScalarType;
    int DataExtent[6];
    double DataSpacing[3];
    double DataOrigin[3];

    double Tolerance;
    double ZFPBitBudget;
    bool ZFPOnly;
    int SQMethod;

    virtual int RequestInformation(vtkInformation *request,
                                   vtkInformationVector **inputVector,
                                   vtkInformationVector *outputVector);

    virtual void ExecuteDataWithInformation(vtkDataObject *output,
                                           vtkInformation *outInfo);

    virtual int FillOutputPortInformation(int port, vtkInformation *info);
    virtual int FillInputPortInformation(int port, vtkInformation *info);

  private:

    FILE                        *fp;
    bool                        validated;

    Triangulation               *internalTriangulation_;
    TopologicalSimplification   topologicalSimplification_;
};

#endif // _VTK_TOPOLOGICALCOMPRESSIONREADER_H

