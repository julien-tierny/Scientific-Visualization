#include <ttkTopologicalCompressionReader.h>
#include <zlib.h>

vtkStandardNewMacro(ttkTopologicalCompressionReader);

/** Override **/

ttkTopologicalCompressionReader::ttkTopologicalCompressionReader() {

  this->FileName = NULL;
  this->Segmentation = new vector<int>();

  this->DataExtent[0] = 0;  this->DataExtent[1] = 0;
  this->DataExtent[2] = 0;  this->DataExtent[3] = 0;
  this->DataExtent[4] = 0;  this->DataExtent[5] = 0;

  this->DataScalarType = VTK_DOUBLE;

  this->DataOrigin[0] = this->DataOrigin[1] = this->DataOrigin[2] = 0.0;
  this->DataSpacing[0] = this->DataSpacing[1] = this->DataSpacing[2] = 1.0;

  this->validated = false;
  this->fp = NULL;

  this->SetNumberOfInputPorts(0);
  this->SetNumberOfOutputPorts(1);
}

int ttkTopologicalCompressionReader::RequestInformation(
    vtkInformation *request,
    vtkInformationVector **inputVector,
    vtkInformationVector *outputVector)
{
  if (this->FileName == NULL) { return 1; }
  if (fp != NULL) { return 1; }
  fp = fopen(this->FileName, "rb"); // binary mode
  if (fp == NULL) { return 1; }
  this->validated = true;

  // Fill spacing, origin, extent, scalar type
  // L8 tolerance, ZFP factor
  this->ReadMetaData();

  vtkInformation *outInfo = outputVector->GetInformationObject(0);
  outInfo->Set(vtkDataObject::SPACING(), this->DataSpacing, 3);
  outInfo->Set(vtkDataObject::ORIGIN(), this->DataOrigin, 3);
  outInfo->Set(vtkStreamingDemandDrivenPipeline::WHOLE_EXTENT(), this->DataExtent, 6);

  int numberOfVertices = 1;
  for (int i = 0; i < 3; ++i)
    numberOfVertices *= (1 + this->DataExtent[2*i + 1] - this->DataExtent[2*i]);
  outInfo->Set(vtkDataObject::FIELD_NUMBER_OF_TUPLES(), numberOfVertices);

  vtkDataObject::SetPointDataActiveScalarInfo(outInfo, this->DataScalarType, 1);

  return 1;
}

void ttkTopologicalCompressionReader::ExecuteDataWithInformation(
    vtkDataObject *output,
    vtkInformation *outInfo)
{

  /** Initialize **/
  if (!(this->validated)) return;
  if (fp == NULL) { return; }

  vtkImageData *out = vtkImageData::SafeDownCast(output);
  int* uExtent = outInfo->Get(vtkStreamingDemandDrivenPipeline::UPDATE_EXTENT());
  out->SetExtent(uExtent);
  int scalarType = vtkImageData::GetScalarType(outInfo);
  int numComponents = vtkImageData::GetNumberOfScalarComponents(outInfo);
  out->AllocateScalars(scalarType, numComponents);

  int *outExt = out->GetExtent();
  void *outPtr = out->GetScalarPointerForExtent(outExt);

  // Do read topology.
  if (!(this->ZFPOnly))
    this->ReadTopology();

  // Get altered geometry.
  // Rebuild topologically consistent geometry.
  this->ReadGeometry(out, outPtr, this->Tolerance);

  if (fflush(fp)) {
    fclose(fp); fp = NULL; this->validated = false;
    return;
  }

  fclose(fp);
  fp = NULL;
  this->validated = false;
}

int ttkTopologicalCompressionReader::ReadMetaData()
{
  // -1. ZFP only type.
  fread(&(this->ZFPOnly), sizeof(bool), 1, fp);

  // 0. SQ type
  fread(&(this->SQMethod), sizeof(int), 1, fp);

  // 1. DataType
  fread(&(this->DataScalarType), sizeof(int), 1, fp);
  // this->DataScalarType = VTK_DOUBLE;

  // 2. Data extent, spacing, origin
  for (int i = 0; i < 6; ++i)
    fread(&(this->DataExtent[i]), sizeof(int), 1, fp);
  for (int i = 0; i < 3; ++i)
    fread(&(this->DataSpacing[i]), sizeof(double), 1, fp);
  for (int i = 0; i < 3; ++i)
    fread(&(this->DataOrigin[i]), sizeof(double), 1, fp);

  // 4. Error tolerance (relative percentage)
  fread(&(this->Tolerance), sizeof(double), 1, fp);

  // 5. Lossy compressor ratio
  fread(&(this->ZFPBitBudget), sizeof(double), 1, fp);

  return 1;
}

int ttkTopologicalCompressionReader::ReadTopology()
{

  int numberOfSegments;
  int numberOfVertices;

  fread(&numberOfVertices, sizeof(int), 1, fp);
  fread(&numberOfSegments, sizeof(int), 1, fp);

  int numberOfBitsPerSegment =
      ttkTopologicalCompressionWriter::log2(numberOfSegments) + 1;

  // TODO [MEDIUM] support long int
  if (numberOfBitsPerSegment > 32) return -3;

  // Decode
  int currentCell = 0;
  int offset = 0;
  int maskerRank = 0;
  int oldCompressedInt = 0;
  vector<int>* segmentation = new vector<int>();

  while (currentCell < numberOfVertices) {

    // if (currentCell % 30 == 28) {
    //   cout << "test" << endl;
    // }

    int compressedInt;
    fread(&compressedInt, sizeof(int), 1, fp);

    while (offset + numberOfBitsPerSegment <= 32) {

      // Size of segment < size of compressed int
      int currentSegment = compressedInt;

      if (maskerRank == 0) {
        currentSegment <<= (32 - offset - numberOfBitsPerSegment);

        if (currentSegment < 0) {
          currentSegment &= 2147483647;
          currentSegment >>= (32 - numberOfBitsPerSegment);
          currentSegment |= (1<<(numberOfBitsPerSegment - 1));
        } else {
          currentSegment >>= (32 - numberOfBitsPerSegment);
        }

        offset += numberOfBitsPerSegment;
      }

      // Got overlapping mask.
      else {
        currentSegment <<= (32 - offset);
        if (currentSegment < 0) {
          currentSegment &= 2147483647;
          currentSegment >>= (32 - numberOfBitsPerSegment);
          currentSegment |= (1<<(numberOfBitsPerSegment - 1));
        } else {
          currentSegment >>= (32 - numberOfBitsPerSegment);
        }

        int nextSegment = currentSegment;

        if (oldCompressedInt < 0) {
          oldCompressedInt &= 2147483647;
          oldCompressedInt >>= maskerRank;
          oldCompressedInt |= (1<<(32-maskerRank-1));
        } else {
          oldCompressedInt >>= maskerRank;
        }

        currentSegment = nextSegment | oldCompressedInt;
        maskerRank = 0;
      }

      segmentation->push_back(currentSegment);
      currentCell++; // Go to next cell.

    }

    // Overlapping mask into next container.
    {
      oldCompressedInt = compressedInt;
      if (offset == 32) {
        maskerRank = 0;
      } else {
        maskerRank = offset;
        offset += numberOfBitsPerSegment;
      }
      offset %= 32;
    }

  }

  // cout << numberOfVertices << " vertices" << endl;
  // cout << numberOfSegments << " segments" << endl;
  // for (int i = 0; i < std::min(numberOfVertices, 100); ++i) {
  //   cout << segmentation->at(i) << " ";
  // } cout << endl;

  this->Segmentation = segmentation;

  return 0;
}

int ttkTopologicalCompressionReader::ReadGeometry(
    vtkImageData *data,
    void *oopt,
    double zfpRate)
{

  data->GetPointData()->RemoveArray(0);

  int sqMethod = this->SQMethod;

  vector<tuple<double, int>> mappings;
  vector<tuple<double, int>> mappingsSortedPerValue;
  vector<tuple<int, double, int>> constraints;
  auto cmp = [](const tuple<double, int>& a,
                const tuple<double, int>& b)
  { return get<1>(a) > get<1>(b); };
  auto cmp2 = [](const tuple<double, int>& a,
                 const tuple<double, int>& b)
  { return get<0>(a) < get<0>(b); };
  double min = 0, max = 0;
  int nbConstraints = 0;

  if (! (this->ZFPOnly)) {
    // 1.a. Read mapping.
    int mappingSize;
    fread(&(mappingSize), sizeof(int), 1, fp);

    for (int i = 0; i < mappingSize; ++i) {
      int idv;
      fread(&idv, sizeof(int), 1, fp);
      double value;
      fread(&value, sizeof(double), 1, fp);

      mappings.push_back(make_tuple(value, idv));
      mappingsSortedPerValue.push_back(make_tuple(value, idv));
    }

    // Sort mapping.
    std::sort(mappings.begin(), mappings.end(), cmp);
    std::sort(mappingsSortedPerValue.begin(), mappingsSortedPerValue.end(), cmp2);

    // 1.b. Read constraints.
    fread(&nbConstraints, sizeof(int), 1, fp);

    for (int i = 0; i < nbConstraints; ++i) {
      int idVertex;
      double value;
      int vertexType;

      fread(&idVertex, sizeof(int), 1, fp);
      fread(&value, sizeof(double), 1, fp);
      fread(&vertexType, sizeof(int), 1, fp);

      if (i == 0) {
        min = value;
        max = value;
      }
      if (value < min) min = value;
      if (value > max) max = value;

      constraints.push_back(make_tuple(idVertex, value, vertexType));
    }
  }


  // Prepare array reconstruction.
  int nx = 1 + this->DataExtent[1] - this->DataExtent[0];
  int ny = 1 + this->DataExtent[3] - this->DataExtent[2];
  int nz = 1 + this->DataExtent[5] - this->DataExtent[4];
  int vertexNumber = nx * ny * nz;
  // Data container.
  data->GetPointData()->SetNumberOfTuples(vertexNumber);
  vtkSmartPointer<vtkDoubleArray> decompressed = vtkSmartPointer<vtkDoubleArray>::New();
  decompressed->SetNumberOfTuples(vertexNumber);
  decompressed->SetName("Decompressed");
  // Offsets container.
  vtkSmartPointer<vtkIntArray> vertexOffset = vtkSmartPointer<vtkIntArray>::New();
  vertexOffset->SetNumberOfTuples(vertexNumber);
  vertexOffset->SetName("Offsets");
  // Set pointers.
  data->GetPointData()->AddArray(decompressed);
  data->GetPointData()->AddArray(vertexOffset);

  double *array;
  if (this->ZFPBitBudget > 64.0 || this->ZFPBitBudget <= 0) {

    // 2.a. (2.) Affect values to points thanks to topology indices.
    vector<int> segmentation = *(this->Segmentation);
    for (int i = 0; i < vertexNumber; ++i)
    {
      int seg = segmentation[i];
      auto end = mappings.end();
      auto it = std::lower_bound(mappings.begin(), mappings.end(), make_tuple(0, seg), cmp);
      if (it != end) {
        tuple<double, int> tt = *it;
        double value = get<0>(tt);
        int sseg = get<1>(tt);
        if (seg != sseg) cout << "Decompression mismatch (" << seg << ", " << sseg << ")" << endl;

        decompressed->SetTuple1(i, value);
      } else {
        cout << "Could not find " << seg << " index." << endl;
        tuple<double, int> tt = *it;
        double value = get<0>(tt);
        decompressed->SetTuple1(i, value);
      }
    }

    array = (double*) decompressed->GetVoidPointer(0);

  } else {
    // 2.b. (2.) Read with ZFP.
    array = new double[vertexNumber];
    zfpc::compress(array, nx, ny, nz, ZFPBitBudget, true, fp);
    decompressed->SetArray(array, vertexNumber, 1);
  }

  if (sqMethod == 0 || sqMethod == 3) {
    for (int i = 0; i < (int) constraints.size(); ++i) {
      tuple<int, double, int> t = constraints[i];
      int id = get<0>(t);
      double val = get<1>(t);
      decompressed->SetTuple1(id, val);
    }
  }

  // double tolerance = this->Tolerance;
  if (min == max) {
    cout << "[TopologicalCompressionReader] empty scalar field range." << endl;
  } else {
    // tolerance *= (max - min);
  }

  if (sqMethod == 1 || sqMethod == 2)
    return 0;

  if (this->ZFPOnly)
    return 0;

  // 2.b. (3.) Crop whatever doesn't fit in topological intervals.
  vector<int> segmentation = *(this->Segmentation);
  int numberOfMisses = 0;
  for (int i = 0; i < vertexNumber; ++i)
  {
    int seg = segmentation[i];
    auto end = mappings.end();
    auto it = std::lower_bound(mappings.begin(), mappings.end(), make_tuple(0, seg), cmp);
    if (it != end) {
      tuple<double, int> tt = *it;
      double value = get<0>(tt);
      int sseg = get<1>(tt);
      if (seg != sseg)
        cout << "[TopologicalCompressionReader] Decompression mismatch."
             << endl;

      auto it2 = std::lower_bound(mappingsSortedPerValue.begin(),
                                  mappingsSortedPerValue.end(),
                                  make_tuple(value, 0), cmp2);

      if (it2 != mappingsSortedPerValue.end()
          && it2 != mappingsSortedPerValue.begin()
          && (it2+1) != mappingsSortedPerValue.end())
      {
        double vv0 = get<0>(*(it2-1));
        // double vv1 = get<0>(*(it2));
        double vv2 = get<0>(*(++it2));
        // double m0 = (vv0 + vv1) / 2;
        // double m1 = (vv1 + vv2) / 2;

        if (array[i] < vv0) {
          numberOfMisses++;
          array[i] = vv0;
        } else if (array[i] > vv2) {
          numberOfMisses++;
          array[i] = vv2;
        }
      } else {
        if ((it2 == mappingsSortedPerValue.end()
             || (it2+1) == mappingsSortedPerValue.end())
            && array[i] > max)
        {
          numberOfMisses++;
          array[i] = max;
        } else if
            ((it2 == mappingsSortedPerValue.begin()
              || (it2-1) == mappingsSortedPerValue.begin())
             && array[i] < min)
        {
          numberOfMisses++;
          array[i] = min;
        }
      }

    } else {
      cout << "[TopologicalCompressionReader] Error looking for topo index."
           << endl;
    }
  }

  if (numberOfMisses > 0) {
    cout << "[TopologicalCompressionReader] Missed "
         << numberOfMisses << " values." << endl;
  }

  // 2.b. (4.) Apply topological simplification with min/max constraints.

  // Offsets.
  int* inputOffsets = new int[vertexNumber];
  for (int i = 0; i < vertexNumber; ++i)
    inputOffsets[i] = i;

  // Triangulate.
  ttkImageData* triang = ttkImageData::New();
  triang->setInputData(data);
  internalTriangulation_ = ttkTriangulation::getTriangulation(triang);
  topologicalSimplification_.setupTriangulation(internalTriangulation_);
  Modified();

  // Preprocess simplification.
  int* critConstraints = new int[nbConstraints];
  for (int i = 0; i < nbConstraints; ++i) {
    tuple<int, double, int> t = constraints[i];
    int id = get<0>(t);
    double val = get<1>(t);
    int type = get<2>(t);

    if (type == 0)

    array[id] = val;

    // Smoothe neighborhood (along with offsets).
    int neighborNumber = internalTriangulation_->getVertexNeighborNumber(id);
    for(int j = 0; j < neighborNumber; ++j) {
      int neighbor;
      internalTriangulation_->getVertexNeighbor(id, j, neighbor);

      if (type == 1) { // Local_maximum.
        if (array[neighbor] > val) array[neighbor] = val;
        if (array[neighbor] == val && inputOffsets[neighbor] > inputOffsets[id]) {
          int tmp = inputOffsets[id];
          inputOffsets[id] = inputOffsets[neighbor];
          inputOffsets[neighbor] = tmp;
        }
      } else if (type == -1) { // Local_minimum.
        if (array[neighbor] < val) array[neighbor] = val;
        if (array[neighbor] == val && inputOffsets[neighbor] < inputOffsets[id]) {
          int tmp = inputOffsets[id];
          inputOffsets[id] = inputOffsets[neighbor];
          inputOffsets[neighbor] = tmp;
        }
      } else if (type == 0) { // Saddle
      }
    }

    critConstraints[i] = id;
  }

  double* inArray = new double[vertexNumber];
  for (int i = 0; i < vertexNumber; ++i) inArray[i] = array[i];
  int *outOffsets = new int[vertexNumber];
  for (int i = 0; i < vertexNumber; ++i) outOffsets[i] = 0;

  topologicalSimplification_.setInputScalarFieldPointer(inArray);
  topologicalSimplification_.setOutputScalarFieldPointer(array);
  topologicalSimplification_.setInputOffsetScalarFieldPointer(inputOffsets);
  topologicalSimplification_.setOutputOffsetScalarFieldPointer(outOffsets);
  topologicalSimplification_.setVertexIdentifierScalarFieldPointer(critConstraints);
  topologicalSimplification_.setConstraintNumber(nbConstraints);

  int status = 0;
  status = topologicalSimplification_.execute<double>();
  if (status != 0) { return status; }

  // Apply offsets.
  for (int i = 0; i < vertexNumber; ++i)
    vertexOffset->SetTuple1(i, outOffsets[i]);

  delete[] critConstraints;
  return 0;
}

int ttkTopologicalCompressionReader::FillOutputPortInformation(int port, vtkInformation *info)
{
  info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkImageData");
  return 1;
}

int ttkTopologicalCompressionReader::FillInputPortInformation(int port, vtkInformation *info)
{
  info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkImageData");
  return 1;
}

