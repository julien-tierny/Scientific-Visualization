#include                  "ttkTopologicalCompressionWriter.h"

vtkStandardNewMacro(ttkTopologicalCompressionWriter);

/** Override **/

void ttkTopologicalCompressionWriter::SetSegmentation(
  int* seg)
{
  this->Segmentation = seg;
}

void ttkTopologicalCompressionWriter::SetCriticalConstraints(
    void* criticalConstraints)
{
  this->CriticalConstraints = criticalConstraints;
}

void ttkTopologicalCompressionWriter::SetMapping(
    void* mapping)
{
  this->Mapping = mapping;
}

ttkTopologicalCompressionWriter::ttkTopologicalCompressionWriter()
{
  this->FileType = VTK_BINARY;
  this->FileName = NULL;
}

void ttkTopologicalCompressionWriter::WriteData()
{

  vtkDataObject *input = this->GetInput();
  vtkImageData *vti = vtkImageData::SafeDownCast(input);

  // Open file.
  FILE *fp;
  if ((fp = fopen(this->FileName, "wb")) == NULL)
  {
    // Error
    return;
  }

  // Get topological compression output.

  // Write metadata.
  this->WriteMetaData(fp, vti);

  // Encode, lossless compress and write topology.
  if (!(this->ZFPOnly))
    this->WriteTopology(fp);

  // Write altered geometry.
  this->WriteGeometry<double>(fp, vti);

  if (fflush(fp)) {
    fclose(fp);
    return;
  }

  fclose(fp);
}


/** Private **/

int ttkTopologicalCompressionWriter::log2(
    int val)
{
  if (val == 0) return UINT_MAX;
  if (val == 1) return 0;
  int ret = 0;
  while (val > 1) {
    val >>= 1;
    ret++;
  }
  return ret;
}

int ttkTopologicalCompressionWriter::WriteMetaData(
    FILE *fp, vtkImageData *vti)
{

  // -1. zfpOnly
  fwrite(&(this->ZFPOnly), sizeof(bool), 1, fp);

  // 0. SQ type
  const char* sq = SQMethod.c_str();
  int sqType = (strcmp(sq, "") == 0) ? 0 :
               (strcmp(sq, "r") == 0 || strcmp(sq, "R") == 0) ? 1 :
               (strcmp(sq, "d") == 0 || strcmp(sq, "D") == 0) ? 2 : 3;
  fwrite(&sqType, sizeof(int), 1, fp);

  // 1. DataType
  int dataScalarType = vti->GetPointData()->GetArray(0)->GetDataType();
  fwrite(&dataScalarType, sizeof(int), 1, fp);

  // 2. Data extent, spacing, origin
  int *dataExtent = vti->GetExtent();
  for (int i = 0; i < 6; ++i)
    fwrite(&dataExtent[i], sizeof(int), 1, fp);
  double *dataSpacing = vti->GetSpacing();
  for (int i = 0; i < 3; ++i)
    fwrite(&dataSpacing[i], sizeof(double), 1, fp);
  double *dataOrigin = vti->GetOrigin();
  for (int i = 0; i < 3; ++i)
    fwrite(&dataOrigin[i], sizeof(double), 1, fp);

  // 4. Tolerance
  fwrite(&(this->Tolerance), sizeof(double), 1, fp);

  // 5. ZFP ratio
  fwrite(&(this->ZFPBitBudget), sizeof(double), 1, fp);

  return 1;
}

int ttkTopologicalCompressionWriter::WriteTopology(
    FILE *fp)
{

  int numberOfSegments = this->NbSegments;
  int numberOfVertices = this->NbVertices;
  int* segmentation = this->Segmentation;

  // Test arguments.
  if (numberOfSegments < 1) return -1;

  fwrite (&numberOfVertices, sizeof(int), 1, fp);
  fwrite (&numberOfSegments, sizeof(int), 1, fp);

  // Compute number of bits pler segments
  // (can be deduced at read-time from numberOfSegments)
  int numberOfBitsPerSegment =
      ttkTopologicalCompressionWriter::log2(numberOfSegments) + 1;

  // TODO [MEDIUM] support long int
  if (numberOfBitsPerSegment > 32) return -3;

  // Encode
  int currentCell = 0;
  int offset = 0;
  int maskerRank = 0;
  while (currentCell < numberOfVertices) {

    // Create next container.
    int compressedInt = 0;

    // Write regularly all segments until one overlaps
    // two containers.
    while (offset + numberOfBitsPerSegment <= 32) {

      int currentSegment = segmentation[currentCell];

      // If applicable, fill last part of current segment.
      if (maskerRank != 0) {
        // Always a positive int.
        currentSegment = currentSegment >> (numberOfBitsPerSegment - offset);
        // (numberOfBitsPerSegment - maskerRank - 1);
        maskerRank = 0;
        compressedInt |= currentSegment;

      } else {
        int cursor = (currentSegment << offset); // 0es after <<
        compressedInt |= cursor;
        offset += numberOfBitsPerSegment;
      }

      currentCell++; // Next cell.

    }

    // Test for overflow filling last part of current container.
    if (currentCell >= numberOfVertices) {
      fwrite(&compressedInt, sizeof(int), 1, fp);
      break;
    }

    // Write current segment into last part of current container,
    // to be continued into next container.
    {
      int currentSegment = segmentation[currentCell];

      if (offset == 32) {
        // currentCell++;
      } else {
        int cursor = (currentSegment << offset);
        compressedInt = compressedInt | cursor;

        maskerRank = 32 - offset;
        offset += numberOfBitsPerSegment;
      }

      offset %= 32;
    }

    // Dump current container.
    fwrite(&compressedInt, sizeof(int), 1, fp);
  }

  return 0;
}

template <typename T>
int ttkTopologicalCompressionWriter::WriteGeometry(
    FILE *fp, vtkImageData *vti)
{

  if (!(this->ZFPOnly)) {
    // 1. Write segmentation map.
    vector<tuple<T, int>>* mapping = (static_cast<vector<tuple<T, int>>*> (this->Mapping));
  
    // Size.
    int mappingSize = mapping->size();
    fwrite(&mappingSize, sizeof(int), 1, fp);
  
    // Segmentation values for each particular index.
    for (int i = 0; i < mappingSize; ++i) {
      tuple<T, int> t = mapping->at(i);
      int idv = get<1>(t);
      fwrite(&idv, sizeof(int), 1, fp);
  
      double value = (double) get<0>(t);
      fwrite(&value, sizeof(double), 1, fp);
    }
  
    // Write critical constraints.
    vector<tuple<int, T, int>> constraints =
        *((vector<tuple<int, T, int>>*) this->CriticalConstraints);
  
    int nbConstraints = (int) constraints.size();
    fwrite(&nbConstraints, sizeof(int), 1, fp);
    for (int i = 0; i < nbConstraints; ++i) {
      tuple<int, T, int> t = constraints[i];
      int idVertex = get<0>(t);
      double value = (double) get<1>(t);
      int vertexType = get<2>(t);
  
      fwrite(&idVertex, sizeof(int), 1, fp);
      fwrite(&value, sizeof(double), 1, fp);
      fwrite(&vertexType, sizeof(int), 1, fp);
    }
  }


  if (this->ZFPBitBudget < 64.0 && this->ZFPBitBudget > 0) {
    // Write zfp-compressed array.
    int *dataExtent = vti->GetExtent();
    int nx = 1 + dataExtent[1] - dataExtent[0];
    int ny = 1 + dataExtent[3] - dataExtent[2];
    int nz = 1 + dataExtent[5] - dataExtent[4];

    double *toCompress = NULL;
    int vertexNumber = nx * ny * nz;

    switch (vti->GetPointData()->GetArray(0)->GetDataType()) {
      case VTK_DOUBLE             : {
        toCompress = (double*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
      }; break;
      case VTK_FLOAT              : {
        float *tt = (float*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_LONG_LONG          : {
        long long *tt =(long long*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_UNSIGNED_LONG_LONG : {
        unsigned long long *tt = (unsigned long long*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_ID_TYPE            : {
        vtkIdType *tt = (vtkIdType*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_LONG               : {
        long *tt = (long*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_UNSIGNED_LONG      : {
        unsigned long *tt = (unsigned long*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_INT                : {
        int *tt = (int*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_UNSIGNED_INT       : {
        unsigned int *tt = (unsigned int*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_SHORT              : {
        short *tt = (short*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_UNSIGNED_SHORT     : {
        unsigned short *tt = (unsigned short*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_CHAR               : {
        char *tt = (char*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_SIGNED_CHAR        : {
        signed char *tt = (signed char*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
      case VTK_UNSIGNED_CHAR      : {
        unsigned char *tt = (unsigned char*) vti->GetPointData()->GetArray(0)->GetVoidPointer(0);
        toCompress = new double[vertexNumber];
        for (int i = 0; i < vertexNumber; ++i)
          toCompress[i] = (double) tt[i];
      }; break;
    }
    zfpc::compress(toCompress, nx, ny, nz, ZFPBitBudget, false, fp);
  }

  return 1;
}

int ttkTopologicalCompressionWriter::FillInputPortInformation(int, vtkInformation *info)
{
  info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkImageData");
  return 1;
}

