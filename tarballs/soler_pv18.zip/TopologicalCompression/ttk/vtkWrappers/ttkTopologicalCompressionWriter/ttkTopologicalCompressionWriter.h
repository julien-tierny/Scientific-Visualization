/// \ingroup vtkWrappers
/// \class ttkTopologicalCompressionWriter
/// \date 21/04/2017
///
/// \brief VTK-filter that wraps the topologicalCompressionWriter processing package.

#ifndef _VTK_TOPOLOGICALCOMPRESSIONWRITER_H
#define _VTK_TOPOLOGICALCOMPRESSIONWRITER_H

// TTK
#include                  <ttkWrapper.h>

// VTK
#include                  <vtkCharArray.h>
#include                  <vtkDataArray.h>
#include                  <vtkDataSet.h>
#include                  <vtkDataSetAlgorithm.h>
#include                  <vtkDoubleArray.h>
#include                  <vtkFiltersCoreModule.h>
#include                  <vtkFloatArray.h>
#include                  <vtkInformation.h>
#include                  <vtkIntArray.h>
#include                  <vtkObjectFactory.h>
#include                  <vtkPointData.h>
#include                  <vtkSmartPointer.h>
#include                  <vtkUnstructuredGrid.h>
#include                  <vtkCellData.h>
#include                  <vtkWriter.h>

// STD
#include                  <string>
#include                  <iostream>
#include                  <fstream>
#include                  <limits.h>

// Other
#include                  "zlib.h"
#include                  "zfp/zfp.cpp"

class VTKFILTERSCORE_EXPORT ttkTopologicalCompressionWriter
    : public vtkWriter
{

  public:

    static ttkTopologicalCompressionWriter *New();
    vtkTypeMacro(ttkTopologicalCompressionWriter, vtkWriter);

    vtkSetStringMacro(FileName);
    vtkGetStringMacro(FileName);

    vtkGetMacro(Tolerance, double);
    vtkSetMacro(Tolerance, double);

    vtkGetMacro(ZFPBitBudget, double);
    vtkSetMacro(ZFPBitBudget, double);

    vtkGetMacro(ZFPOnly, bool);
    vtkSetMacro(ZFPOnly, bool);

    //
    vtkGetMacro(NbSegments, int);
    vtkSetMacro(NbSegments, int);

    vtkGetMacro(NbVertices, int);
    vtkSetMacro(NbVertices, int);

    vtkGetMacro(SQMethod, string);
    vtkSetMacro(SQMethod, string);

    void SetSegmentation(int* seg);

    void SetCriticalConstraints(void* criticalConstraints);

    void SetMapping(void* mapping);

    static int log2(int val);

  protected:

    ttkTopologicalCompressionWriter();

    ~ttkTopologicalCompressionWriter() {
      delete[] this->FileName;
      delete[] this->Segmentation;
    }

    virtual int FillInputPortInformation(int port, vtkInformation *info);

    void WriteData();

    int WriteMetaData(FILE *fp, vtkImageData *vti);

    int WriteTopology(FILE *fp);

    template <typename T>
    int WriteGeometry(FILE *fp, vtkImageData *vti);

  private:
    int   FileType;

    // Writer parameters.
    char *FileName;
    double ZFPBitBudget;
    bool ZFPOnly;

    // Compression results.
    int* Segmentation;
    void* Mapping;
    void* CriticalConstraints;
    double Tolerance;
    int NbSegments;
    int NbVertices;
    string SQMethod;

    ttkTopologicalCompressionWriter(
        const ttkTopologicalCompressionWriter&);
    void operator=(
        const ttkTopologicalCompressionWriter&);

};

#endif // _VTK_TOPOLOGICALCOMPRESSIONWRITER_H

