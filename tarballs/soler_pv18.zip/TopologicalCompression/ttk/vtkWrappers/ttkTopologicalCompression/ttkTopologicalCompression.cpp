#include                  "ttkTopologicalCompression.h"

vtkStandardNewMacro(ttkTopologicalCompression)

int ttkTopologicalCompression::doIt(
    vector<vtkDataSet *> &inputs,
    vector<vtkDataSet *> &outputs)
{

  // Prepare IO
  vtkDataSet *input1 = inputs[0];
  vtkDataSet *output1 = outputs[0];

  triangulation_.setWrapper(this);
  topologicalCompression_.setWrapper(this);

  // Triangulate
  triangulation_.setInputData(input1);
  internalTriangulation_ = ttkTriangulation::getTriangulation(input1);
  topologicalCompression_.setupTriangulation(internalTriangulation_);
  Modified();

  if (!input1) return -1;

  // use a pointer-base copy for the input data -- to adapt if your wrapper does
  // not produce an output of the type of the input.
  output1->ShallowCopy(input1);
  
  // in the following, the target scalar field of the input is replaced in the 
  // variable 'output' with the result of the computation.
  // if your wrapper produces an output of the same type of the input, you 
  // should proceed in the same way.
  vtkDataArray *inputScalarField = NULL;
  
  if (ScalarField.length())
    inputScalarField = input1->GetPointData()->GetArray(ScalarField.data());
  else
    inputScalarField = input1->GetPointData()->GetArray(0);

  if (!inputScalarField) return -1;
  
  // allocate the memory for the output scalar field
  if(!outputScalarField_) {
    switch(inputScalarField->GetDataType()) {
      case VTK_CHAR:    outputScalarField_ = vtkCharArray::New();
        break;
      case VTK_DOUBLE:  outputScalarField_ = vtkDoubleArray::New();
        break;
      case VTK_FLOAT:   outputScalarField_ = vtkFloatArray::New();
        break;
      case VTK_INT:     outputScalarField_ = vtkIntArray::New();
        break;

      default:
        {
          stringstream msg;
          msg << "[vtkTopologicalCompression] Unsupported data type :(" << endl;
          dMsg(cerr, msg.str(), fatalMsg);
        }
        break;
    }
  }

  outputScalarField_->SetNumberOfTuples(inputScalarField->GetNumberOfTuples());
  outputScalarField_->SetName(inputScalarField->GetName());

  // Replace (using AddArray with the same name) initial array
  // with computation result
  output1->GetPointData()->AddArray(outputScalarField_);

  // Call TopologicalCompression
  switch (inputScalarField->GetDataType()) {
    vtkTemplateMacro((
      {
        topologicalCompression_.setInputDataPointer(inputScalarField->GetVoidPointer(0));
        topologicalCompression_.setSQ(SQMethod);
        topologicalCompression_.setUseTopologicalSimplification(UseTopologicalSimplification);
        topologicalCompression_.setZFPOnly(ZFPOnly);
        topologicalCompression_.setSubdivide(Subdivide);
        topologicalCompression_.setOutputDataPointer(outputScalarField_->GetVoidPointer(0));
        topologicalCompression_.execute<VTK_TT>(Tolerance);
      }
    ));
  }

  // Filter.
  if (OutputFile.size() < 1) return 0;

  // WRITE INTO FILE.
  vtkSmartPointer<ttkTopologicalCompressionWriter> writer =
    vtkSmartPointer<ttkTopologicalCompressionWriter>::New();

  // CAREFUL! must be a vtkImageData
  writer->SetInputData(vtkImageData::SafeDownCast(input1));
  writer->SetSQMethod(SQMethod);
  writer->SetNbSegments(topologicalCompression_.getNbSegments());
  writer->SetNbVertices(topologicalCompression_.getNbVertices());
  writer->SetSegmentation(topologicalCompression_.getSegmentation());
  writer->SetMapping(topologicalCompression_.getMapping());
  writer->SetCriticalConstraints(topologicalCompression_.getCriticalConstraints());
  writer->SetTolerance(this->Tolerance);
  writer->SetZFPBitBudget(this->ZFPBitBudget);
  writer->SetZFPOnly(this->ZFPOnly);

  const char* path = OutputFile.c_str();
  writer->SetFileName(path);
  writer->Write();

  {
    stringstream msg;
    msg << "[vtkTopologicalCompression] Wrote to "
        << path << endl;
    dMsg(cerr, msg.str(), timeMsg);
  }

  // READ FROM FILE.
  bool debugReader = false;
  if (debugReader) {

    vtkSmartPointer<ttkTopologicalCompressionReader> reader =
        vtkSmartPointer<ttkTopologicalCompressionReader>::New();

    reader->SetFileName(path);
    // reader->Update(0);
    // reader->GetOutput();
    string outputFilePath = OutputFile + ".vti";
    vtkSmartPointer<vtkXMLImageDataWriter> vtiWriter =
        vtkSmartPointer<vtkXMLImageDataWriter>::New();
    vtiWriter->SetFileName(outputFilePath.c_str());
    vtiWriter->SetInputConnection(reader->GetOutputPort());
    vtiWriter->Write();
    {
      stringstream msg;
      msg << "[vtkTopologicalCompression] Read from "
          << path << endl;
      dMsg(cerr, msg.str(), timeMsg);
    }
  }

  return 0;
}

