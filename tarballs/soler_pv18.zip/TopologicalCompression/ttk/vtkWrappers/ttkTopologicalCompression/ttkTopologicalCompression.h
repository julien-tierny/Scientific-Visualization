/// \ingroup vtkWrappers
/// \class vtkTopologicalCompression
/// \date 20/04/2017
///
/// \brief TTK VTK-filter that wraps the topologicalCompression processing package.
///
/// VTK wrapping code for the @TopologicalCompression package.
/// 
/// \param Input Input scalar field (vtkDataSet)
/// \param Output Output scalar field (vtkDataSet)
///
/// This filter can be used as any other VTK filter (for instance, by using the 
/// sequence of calls SetInputData(), Update(), GetOutput()).
///
/// See the corresponding ParaView state file example for a usage example 
/// within a VTK pipeline.
///
/// \sa ttk::TopologicalCompression
#ifndef _VTK_TOPOLOGICALCOMPRESSION_H
#define _VTK_TOPOLOGICALCOMPRESSION_H

// ttk code includes
#include                  <TopologicalCompression.h>
#include                  <ttkWrapper.h>
#include                  <ttkTopologicalCompressionWriter.h>
#include                  <ttkTopologicalCompressionReader.h>

// VTK includes -- to adapt
#include                  <vtkCharArray.h>
#include                  <vtkDataArray.h>
#include                  <vtkDataSet.h>
#include                  <vtkDataSetAlgorithm.h>
#include                  <vtkDoubleArray.h>
#include                  <vtkFiltersCoreModule.h>
#include                  <vtkFloatArray.h>
#include                  <vtkInformation.h>
#include                  <vtkIntArray.h>
#include                  <vtkObjectFactory.h>
#include                  <vtkPointData.h>
#include                  <vtkSmartPointer.h>
#include                  <vtkUnstructuredGrid.h>
#include                  <vtkCellData.h>
#include                  <vtkXMLImageDataWriter.h>

// in this example, this wrapper takes a data-set on the input and produces a 
// data-set on the output - to adapt.
// see the documentation of the vtkAlgorithm class to decide from which VTK 
// class your wrapper should inherit.
class VTKFILTERSCORE_EXPORT ttkTopologicalCompression 
  : public vtkDataSetAlgorithm, public Wrapper
{

  public:
      
    static ttkTopologicalCompression* New();
    
    vtkTypeMacro(ttkTopologicalCompression, vtkDataSetAlgorithm);

    // Default ttk setters
    vtkSetMacro(debugLevel_, int);

    void SetThreadNumber(int threadNumber) {
      ThreadNumber = threadNumber;
      SetThreads();
    }

    void SetUseAllCores(bool onOff) {
      UseAllCores = onOff;
      SetThreads();
    }
    // End of default ttk setters

    // Set/Get macros (arguments)
    vtkSetMacro(ScalarField, string);
    vtkGetMacro(ScalarField, string);

    vtkSetMacro(OutputFile, string);
    vtkGetMacro(OutputFile, string);

    vtkSetMacro(Tolerance, double);
    vtkGetMacro(Tolerance, double);

    vtkSetMacro(ZFPBitBudget, double);
    vtkGetMacro(ZFPBitBudget, double);

    vtkSetMacro(ZFPOnly, double);
    vtkGetMacro(ZFPOnly, double);

    vtkSetMacro(SQMethod, string);
    vtkGetMacro(SQMethod, string);

    vtkSetMacro(Subdivide, bool);
    vtkGetMacro(Subdivide, bool);
    
    vtkSetMacro(UseTopologicalSimplification, bool);
    vtkGetMacro(UseTopologicalSimplification, bool);
    // /Macros

    // Over-ride the input types.
    // By default, this filter has one input and one output, of the same type.
    // Here, you can re-define the input types, on a per input basis.
    // In this example, the first input type is forced to vtkUnstructuredGrid.
    // The second input type is forced to vtkImageData.
//     int FillInputPortInformation(int port, vtkInformation *info){
//       
//       switch(port){
//         case 0:
//           info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkUnstructuredGrid"); 
//           break;
//         case 1:
//           info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkImageData"); 
//           break;
//         default:
//           break;
//       }
//       
//       return 1;
//     }

    // Over-ride the output types.
    // By default, this filter has one input and one output, of the same type.
    // Here, you can re-define the output types, on a per output basis.
    // In this example, the first output type is forced to vtkUnstructuredGrid.
    // The second output type is forced to vtkImageData.
//     int FillOutputPortInformation(int port, vtkInformation *info){
//       
//       switch(port){
//         case 0:
//           info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkUnstructuredGrid"); 
//           break;
//         case 1:
//           info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkImageData"); 
//           break;
//         default:
//           break;
//       }
//       
//       return 1;
//     }

  protected:
   
    ttkTopologicalCompression(){
      
      // Init
      outputScalarField_ = NULL;

      OutputFile = "output";
      Tolerance = 1e-3;
      ZFPBitBudget = 64.0;
      ZFPOnly = false;
      Subdivide = false;
      UseAllCores = false;
      UseTopologicalSimplification = false;
      
      // Specify the number of input and output ports.
      // By default, this filter has one input and one output.
      // In this example, we define 2 inputs and 2 outputs.
      // SetNumberOfInputPorts(2);
      // SetNumberOfOutputPorts(2);
    }
    
    ~ttkTopologicalCompression() {};

    TTK_SETUP();

private:
    
    double                  Tolerance;
    double                  ZFPBitBudget;
    bool                    ZFPOnly;
    string                  SQMethod;
    bool                    Subdivide;
    bool                    UseTopologicalSimplification;
    string                  ScalarField;
    string                  OutputFile;

    vtkDataArray            *outputScalarField_;

    ttkTriangulation        triangulation_;
    Triangulation           *internalTriangulation_;

    TopologicalCompression  topologicalCompression_;
    
};

#endif // _VTK_TOPOLOGICALCOMPRESSION_H

