var searchData=
[
  ['dbl_5fsignificant_5fdigits',['DBL_SIGNIFICANT_DIGITS',['../Os_8h.html#a2ea18a92890363827d8542bdea482411',1,'Os.h']]]
];
