var searchData=
[
  ['flt_5fsignificant_5fdigits',['FLT_SIGNIFICANT_DIGITS',['../Os_8h.html#a483e8427bc753aa48b8c08e3b0ad3748',1,'Os.h']]]
];
