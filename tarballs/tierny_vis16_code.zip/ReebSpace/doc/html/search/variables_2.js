var searchData=
[
  ['caseid_5f',['caseId_',['../classwtfit_1_1FiberSurface_1_1Triangle.html#a17acc0811ec7c0dffe34de8ef406f1f1',1,'wtfit::FiberSurface::Triangle::caseId_()'],['../structwtfit_1_1FiberSurface_1_1__intersectionTriangle.html#a9091891cc99ee4d4a42cd974fc871d68',1,'wtfit::FiberSurface::_intersectionTriangle::caseId_()']]],
  ['criticalpoints_5f',['criticalPoints_',['../classwtfit_1_1ScalarFieldCriticalPoints.html#ab8fba6d6212fab2365a0352e14ac6ea5',1,'wtfit::ScalarFieldCriticalPoints']]],
  ['currentdata_5f',['currentData_',['../classwtfit_1_1ReebSpace.html#a81288d407c453489cb56e1c0fe437e6f',1,'wtfit::ReebSpace']]]
];
