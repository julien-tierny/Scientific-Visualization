var searchData=
[
  ['real_5fmax',['REAL_MAX',['../Os_8h.html#a70fc4e60483cc1a5cb39dd935640cadc',1,'Os.h']]],
  ['real_5fsignificant_5fdigits',['REAL_SIGNIFICANT_DIGITS',['../Os_8h.html#a985264636a55a9eb2225fdb81d6b4d3f',1,'Os.h']]],
  ['real_5ftype',['REAL_TYPE',['../Os_8h.html#a7db5e8ee7c27e6fb5c9caf9d674ea949',1,'Os.h']]],
  ['real_5ftype_5fstring',['REAL_TYPE_STRING',['../Os_8h.html#a5e053fd2ac5137e85ec829cc253d95f8',1,'Os.h']]]
];
