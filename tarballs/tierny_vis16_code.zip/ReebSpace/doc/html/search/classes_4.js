var searchData=
[
  ['geometry',['Geometry',['../classwtfit_1_1Geometry.html',1,'wtfit']]]
];
