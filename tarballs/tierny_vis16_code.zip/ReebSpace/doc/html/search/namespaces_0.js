var searchData=
[
  ['wtfit',['wtfit',['../namespacewtfit.html',1,'']]]
];
