var searchData=
[
  ['jacobi2edges_5f',['jacobi2edges_',['../classwtfit_1_1ReebSpace.html#a32d267323a921ef59100caa5513599ed',1,'wtfit::ReebSpace']]],
  ['jacobisetedges_5f',['jacobiSetEdges_',['../classwtfit_1_1ReebSpace.html#ae9f8add3128f97becead274e3a378f80',1,'wtfit::ReebSpace']]]
];
