var searchData=
[
  ['simplificationcriterion',['SimplificationCriterion',['../classwtfit_1_1ReebSpace.html#a3fc62a0e2ae46cced7bc1ecfc6621552',1,'wtfit::ReebSpace']]]
];
