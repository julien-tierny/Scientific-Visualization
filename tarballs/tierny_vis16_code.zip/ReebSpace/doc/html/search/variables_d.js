var searchData=
[
  ['originaldata_5f',['originalData_',['../classwtfit_1_1ReebSpace.html#a5f842dc2b598db4963f2a48e2bab2a2c',1,'wtfit::ReebSpace']]]
];
