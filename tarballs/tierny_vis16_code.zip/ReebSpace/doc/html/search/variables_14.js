var searchData=
[
  ['welcomemsg_5f',['welcomeMsg_',['../namespacewtfit.html#ac5cfe6bbeab68e8a6397a2fbda2c5863',1,'wtfit']]],
  ['wrapper_5f',['wrapper_',['../classwtfit_1_1Debug.html#acd49a004cc809331a29c652757ae3535',1,'wtfit::Debug']]]
];
