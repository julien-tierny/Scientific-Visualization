var searchData=
[
  ['interpolatebasepoints',['interpolateBasePoints',['../classwtfit_1_1FiberSurface.html#a86cc6aeb67b3bec0c2f419e6367bc1f1',1,'wtfit::FiberSurface']]],
  ['isedgeanglecollapsible',['isEdgeAngleCollapsible',['../classwtfit_1_1FiberSurface.html#afba115ef77d1d2fd3e5b33b6581cd0a3',1,'wtfit::FiberSurface']]],
  ['isedgeflippable',['isEdgeFlippable',['../classwtfit_1_1FiberSurface.html#ab45e2c3a8a6a12b02f4f3060710d93af',1,'wtfit::FiberSurface']]],
  ['isintersectiontrianglecolinear',['isIntersectionTriangleColinear',['../classwtfit_1_1FiberSurface.html#a510bbe23670a6a6a4ad0310e4834d6fd',1,'wtfit::FiberSurface']]],
  ['ispointintriangle',['isPointInTriangle',['../classwtfit_1_1Geometry.html#afbd2d6ab12ba9c41da6fef250f588d7d',1,'wtfit::Geometry::isPointInTriangle(const double *p0, const double *p1, const double *p2, const double *p)'],['../classwtfit_1_1Geometry.html#a28bf2f67243e6c1dc11aa04403cada07',1,'wtfit::Geometry::isPointInTriangle(const float *p0, const float *p1, const float *p2, const float *p)']]],
  ['ispointonsegment',['isPointOnSegment',['../classwtfit_1_1Geometry.html#a129e3ca28973730893efd3520386363f',1,'wtfit::Geometry::isPointOnSegment(const double &amp;x, const double &amp;y, const double &amp;xA, const double &amp;yA, const double &amp;xB, const double &amp;yB)'],['../classwtfit_1_1Geometry.html#a60f241928f64ac962a2cd07791addddc',1,'wtfit::Geometry::isPointOnSegment(const double *p, const double *pA, const double *pB, const int &amp;dimension=3)']]],
  ['issoshigherthan',['isSosHigherThan',['../classwtfit_1_1ScalarFieldCriticalPoints.html#a51fd6bdd352c1a300c3d17879f97d7e5',1,'wtfit::ScalarFieldCriticalPoints']]],
  ['issoslowerthan',['isSosLowerThan',['../classwtfit_1_1ScalarFieldCriticalPoints.html#aaa5592a2b1d6c61d8b9bf6464ed8556b',1,'wtfit::ScalarFieldCriticalPoints']]],
  ['istrianglecolinear',['isTriangleColinear',['../classwtfit_1_1Geometry.html#a6cef3294010131f5602d5e7f25a360b1',1,'wtfit::Geometry']]]
];
