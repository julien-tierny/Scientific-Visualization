var searchData=
[
  ['hasconnectedsheets_5f',['hasConnectedSheets_',['../classwtfit_1_1ReebSpace.html#a1a268c1bed49e4d94f31f8aea1b10255',1,'wtfit::ReebSpace']]],
  ['hasduplicatedvertices',['hasDuplicatedVertices',['../classwtfit_1_1FiberSurface.html#aff9b167b3fbe0af268ffb111db346af7',1,'wtfit::FiberSurface']]],
  ['hassaddleedges_5f',['hasSaddleEdges_',['../classwtfit_1_1ReebSpace_1_1Sheet1.html#a0c1bf153a36f1e6bcb2e9629193cbb15',1,'wtfit::ReebSpace::Sheet1']]],
  ['hypervolume',['hyperVolume',['../classwtfit_1_1ReebSpace.html#a3fc62a0e2ae46cced7bc1ecfc6621552ad35dc8da8ad3b4e82872a345ab9c4a2c',1,'wtfit::ReebSpace']]],
  ['hypervolume_5f',['hyperVolume_',['../classwtfit_1_1ReebSpace_1_1Sheet3.html#a1d8943420ac56860613c19f5c4ea0d8d',1,'wtfit::ReebSpace::Sheet3']]]
];
